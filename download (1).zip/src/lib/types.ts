export type UnitSystem = 'metric' | 'imperial';

export interface Food {
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  servingSize: number; // in grams
}

export interface LoggedMeal {
  id: string;
  food: Food;
  quantity: number; // in grams
}

export interface CalorieTargets {
  dailyCalorieTarget: number;
  macroTargets: {
    proteinGrams: number;
    fatGrams: number;
    carbGrams: number;
  };
}

export interface Supplement {
  name: string;
  description: string;
  benefits: string[];
}

export interface Message {
  role: 'user' | 'model';
  content: string;
}
