"use client";

import React, { useState } from 'react';
import { Calculator, Apple, Bot, LogOut } from 'lucide-react';
import type { CalorieTargets, LoggedMeal } from '@/lib/types';
import CalorieCalculator from '@/components/calorie-calculator';
import MealLogger from '@/components/meal-logger';
import ProgressTracker from '@/components/progress-tracker';
import SupplementInfo from '@/components/supplement-info';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { UnitProvider, useUnits } from '@/hooks/use-units';
import { Button } from '@/components/ui/button';
import { Logo } from '@/components/icons';
import { WorkoutInspiration } from './workout-inspiration';
import { useAuth } from '@/firebase';
import { signOut } from 'firebase/auth';
import { useToast } from '@/hooks/use-toast';
import { ThemeToggle } from '@/components/theme-toggle';

function DashboardContent() {
  const [calorieTargets, setCalorieTargets] = useState<CalorieTargets | null>(null);
  const [loggedMeals, setLoggedMeals] = useState<LoggedMeal[]>([]);
  const { unitSystem, toggleUnitSystem } = useUnits();
  const auth = useAuth();
  const { toast } = useToast();

  const handleMealLog = (meal: LoggedMeal) => {
    setLoggedMeals(prev => [...prev, meal]);
  };

  const handleClearMeals = () => {
    setLoggedMeals([]);
  };
  
  const handleSignOut = async () => {
    try {
      await signOut(auth);
      toast({
        title: "Signed Out",
        description: "You have been successfully signed out.",
      });
    } catch (error) {
       toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to sign out. Please try again.",
      });
    }
  }

  return (
    <main className="flex-1 space-y-4 p-4 md:p-8 pt-6 min-h-screen">
      <div className="flex items-center justify-between space-y-2">
        <div className="flex items-center space-x-2">
          <Logo className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold tracking-tight font-headline">GainzTrack</h1>
        </div>
        <div className="flex items-center space-x-2">
          <ThemeToggle />
          <Button onClick={toggleUnitSystem} variant="outline" size="sm">
            Use {unitSystem === 'metric' ? 'Imperial' : 'Metric'} Units
          </Button>
          <Button onClick={handleSignOut} variant="outline" size="sm">
            <LogOut className="mr-2 h-4 w-4" />
            Sign Out
          </Button>
        </div>
      </div>
      
      <ProgressTracker calorieTargets={calorieTargets} loggedMeals={loggedMeals} />

      <div className="space-y-4">
        <WorkoutInspiration />
      </div>

      <Tabs defaultValue="logger" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="logger">
            <Apple className="mr-2 h-4 w-4" />
            Meal Logger
          </TabsTrigger>
          <TabsTrigger value="calculator">
            <Calculator className="mr-2 h-4 w-4" />
            Target Calculator
          </TabsTrigger>
          <TabsTrigger value="supplements">
            <Bot className="mr-2 h-4 w-4" />
            Supplement Advisor
          </TabsTrigger>
        </TabsList>
        <TabsContent value="logger" className="space-y-4">
          <MealLogger onMealLog={handleMealLog} loggedMeals={loggedMeals} onClearMeals={handleClearMeals} />
        </TabsContent>
        <TabsContent value="calculator" className="space-y-4">
          <CalorieCalculator setCalorieTargets={setCalorieTargets} />
        </TabsContent>
        <TabsContent value="supplements" className="space-y-4">
          <SupplementInfo />
        </TabsContent>
      </Tabs>
    </main>
  );
}

export function Dashboard() {
  return (
    <UnitProvider>
      <DashboardContent />
    </UnitProvider>
  );
}
