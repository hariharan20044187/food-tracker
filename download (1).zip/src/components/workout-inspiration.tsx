"use client";

import Image from 'next/image';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import imageData from '@/lib/placeholder-images.json';
import { Sparkles } from 'lucide-react';

export function WorkoutInspiration() {
  const { workoutInspiration } = imageData;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Sparkles className="mr-2 h-6 w-6 text-accent" />
          Workout Inspiration
        </CardTitle>
        <CardDescription>Get motivated with these exercises.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {workoutInspiration.map((image) => (
            <div key={image.id} className="relative group overflow-hidden rounded-lg">
              <Image
                src={`https://picsum.photos/seed/${image.seed}/${image.width}/${image.height}`}
                alt={image.title}
                width={image.width}
                height={image.height}
                data-ai-hint={image.hint}
                className="object-cover w-full h-full transform transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-0 left-0 p-4">
                <h3 className="text-lg font-bold text-white">{image.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
