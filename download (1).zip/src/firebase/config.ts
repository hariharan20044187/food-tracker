export const firebaseConfig = {
  "projectId": "studio-3521065819-40199",
  "appId": "1:103076979604:web:0a91b89066759c152fe581",
  "apiKey": "AIzaSyDpqU5aJEJaxJvi1zDPHKzKc_JilIOeXA8",
  "authDomain": "studio-3521065819-40199.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "103076979604"
};
