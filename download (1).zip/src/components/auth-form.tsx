"use client";

import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Loader2, LogIn, UserPlus, Ghost } from 'lucide-react';
import { useAuth, useUser, useFirestore, setDocumentNonBlocking } from '@/firebase';
import { doc } from 'firebase/firestore';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInAnonymously,
  AuthErrorCodes
} from 'firebase/auth';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';

const authSchema = z.object({
  email: z.string().email({ message: "Invalid email address." }),
  password: z.string().min(6, { message: "Password must be at least 6 characters." }),
});

type AuthFormValues = z.infer<typeof authSchema>;

export function AuthForm() {
  const [isLogin, setIsLogin] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const auth = useAuth();
  const firestore = useFirestore();
  const { user, isUserLoading } = useUser();
  const { toast } = useToast();
  const router = useRouter();

  const form = useForm<AuthFormValues>({
    resolver: zodResolver(authSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  useEffect(() => {
    if (!isUserLoading && user) {
      router.push('/');
    }
  }, [user, isUserLoading, router]);

  const onSubmit = async (data: AuthFormValues) => {
    setIsLoading(true);
    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, data.email, data.password);
        toast({ title: "Success", description: "Logged in successfully." });
      } else {
        const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password);
        const newUser = userCredential.user;
        
        // Create user document in Firestore
        const userDocRef = doc(firestore, 'users', newUser.uid);
        const userData = {
            id: newUser.uid,
            email: newUser.email,
            name: newUser.email?.split('@')[0] || 'New User',
            unitPreference: 'metric',
            goal: 'maintain',
            activityLevel: 'moderatelyActive'
        }
        setDocumentNonBlocking(userDocRef, userData, { merge: true });

        toast({ title: "Success", description: "Account created successfully." });
      }
    } catch (error: any) {
      let description = "An unexpected error occurred.";
      if (error.code === AuthErrorCodes.INVALID_LOGIN_CREDENTIALS) {
        description = "Invalid email or password. Please try again.";
      } else if (error.code === AuthErrorCodes.EMAIL_EXISTS) {
        description = "An account with this email already exists.";
      }
      toast({
        variant: "destructive",
        title: "Authentication Error",
        description,
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleAnonymousSignIn = async () => {
    setIsLoading(true);
    try {
        const userCredential = await signInAnonymously(auth);
        const newUser = userCredential.user;

         const userDocRef = doc(firestore, 'users', newUser.uid);
         const userData = {
            id: newUser.uid,
            email: `anon-${newUser.uid}@example.com`,
            name: 'Anonymous User',
            unitPreference: 'metric',
            goal: 'maintain',
            activityLevel: 'moderatelyActive'
        }
        setDocumentNonBlocking(userDocRef, userData, { merge: true });

        toast({ title: "Welcome!", description: "Signed in anonymously." });

    } catch (error) {
        toast({
            variant: "destructive",
            title: "Error",
            description: "Could not sign in anonymously.",
        });
    } finally {
        setIsLoading(false);
    }
  };


  return (
    <Card>
      <CardHeader>
        <CardTitle>{isLogin ? 'Welcome Back!' : 'Create an Account'}</CardTitle>
        <CardDescription>
          {isLogin ? 'Log in to continue your fitness journey.' : 'Sign up to start tracking your gainz.'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input placeholder="you@example.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="••••••••" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" disabled={isLoading} className="w-full">
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isLogin ? <><LogIn className="mr-2 h-4 w-4" /> Log In</> : <><UserPlus className="mr-2 h-4 w-4" /> Sign Up</>}
            </Button>
          </form>
        </Form>
      </CardContent>
      <CardFooter className="flex-col space-y-4">
         <div className="relative w-full">
            <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-card px-2 text-muted-foreground">Or continue with</span>
            </div>
        </div>
        <Button onClick={handleAnonymousSignIn} variant="outline" disabled={isLoading} className="w-full">
            {isLoading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
                <><Ghost className="mr-2 h-4 w-4" /> Sign in Anonymously</>
            )}
        </Button>
        <p className="text-sm text-muted-foreground">
          {isLogin ? "Don't have an account?" : 'Already have an account?'}
          <Button variant="link" onClick={() => setIsLogin(!isLogin)} className="px-1">
            {isLogin ? 'Sign Up' : 'Log In'}
          </Button>
        </p>
      </CardFooter>
    </Card>
  );
}
