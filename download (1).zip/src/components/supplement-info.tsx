"use client";

import React from 'react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { supplementData } from '@/lib/data';
import { Info } from 'lucide-react';

export default function SupplementInfo() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Info className="mr-2 h-6 w-6 text-accent" />
          Common Supplements
        </CardTitle>
        <CardDescription>
          General information on popular supplements for gym beginners. Always consult with a healthcare professional before starting any new supplement regimen.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full">
          {supplementData.map(supplement => (
            <AccordionItem value={supplement.name} key={supplement.name}>
              <AccordionTrigger>{supplement.name}</AccordionTrigger>
              <AccordionContent>
                <p className="mb-4 text-muted-foreground">{supplement.description}</p>
                <h4 className="font-semibold mb-2">Potential Benefits:</h4>
                <ul className="list-disc pl-5 space-y-1">
                  {supplement.benefits.map(benefit => <li key={benefit}>{benefit}</li>)}
                </ul>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  );
}
