"use client";

import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useUnits } from '@/hooks/use-units';
import type { CalorieTargets } from '@/lib/types';
import { Loader2, Sparkles } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const formSchema = z.object({
  gender: z.enum(['male', 'female'], { required_error: 'Please select a gender.' }),
  age: z.coerce.number().int().min(1, "Age must be at least 1."),
  weight: z.coerce.number().min(1, "Weight must be positive."),
  height: z.coerce.number().min(1, "Height must be positive."),
  activityLevel: z.enum(['sedentary', 'lightlyActive', 'moderatelyActive', 'veryActive', 'extraActive']),
  goal: z.enum(['weightGain', 'weightLoss', 'maintain']),
});

type CalorieFormValues = z.infer<typeof formSchema>;

interface Props {
  setCalorieTargets: (targets: CalorieTargets | null) => void;
}

const activityMultipliers = {
  sedentary: 1.2,
  lightlyActive: 1.375,
  moderatelyActive: 1.55,
  veryActive: 1.725,
  extraActive: 1.9,
};

const goalAdjustments = {
  weightLoss: -500,
  maintain: 0,
  weightGain: 500,
};

// Mifflin-St Jeor Equation
const calculateBMR = (weightKg: number, heightCm: number, age: number, gender: 'male' | 'female') => {
  if (gender === 'male') {
    return 10 * weightKg + 6.25 * heightCm - 5 * age + 5;
  } else {
    return 10 * weightKg + 6.25 * heightCm - 5 * age - 161;
  }
};

const calculateMacros = (calories: number, goal: 'weightGain' | 'weightLoss' | 'maintain') => {
  let proteinPercentage, fatPercentage;
  
  switch (goal) {
    case 'weightLoss':
      proteinPercentage = 0.35; // 35%
      fatPercentage = 0.25; // 25%
      break;
    case 'weightGain':
      proteinPercentage = 0.30; // 30%
      fatPercentage = 0.25; // 25%
      break;
    default: // maintain
      proteinPercentage = 0.30; // 30%
      fatPercentage = 0.20; // 20%
      break;
  }
  
  const proteinGrams = Math.round((calories * proteinPercentage) / 4);
  const fatGrams = Math.round((calories * fatPercentage) / 9);
  const carbGrams = Math.round((calories - (proteinGrams * 4 + fatGrams * 9)) / 4);
  
  return { proteinGrams, fatGrams, carbGrams };
}


export default function CalorieCalculator({ setCalorieTargets }: Props) {
  const { unitSystem } = useUnits();
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const [result, setResult] = useState<CalorieTargets | null>(null);

  const form = useForm<CalorieFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      gender: undefined,
      age: 25,
      weight: 70,
      height: 175,
      activityLevel: 'moderatelyActive',
      goal: 'maintain',
    },
  });

  const onSubmit = async (data: CalorieFormValues) => {
    setIsLoading(true);
    setResult(null);
    setCalorieTargets(null);

    // Simulate a short delay to mimic API call
    await new Promise(resolve => setTimeout(resolve, 500));

    try {
      const weightKg = unitSystem === 'imperial' ? data.weight * 0.453592 : data.weight;
      const heightCm = unitSystem === 'imperial' ? data.height * 2.54 : data.height;

      const bmr = calculateBMR(weightKg, heightCm, data.age, data.gender);
      const tdee = bmr * activityMultipliers[data.activityLevel];
      const dailyCalorieTarget = Math.round(tdee + goalAdjustments[data.goal]);
      const macroTargets = calculateMacros(dailyCalorieTarget, data.goal);

      const targets: CalorieTargets = { dailyCalorieTarget, macroTargets };

      setCalorieTargets(targets);
      setResult(targets);
      toast({
        title: "Success!",
        description: "Your daily targets have been calculated.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not calculate targets. Please check your inputs.",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const weightUnit = unitSystem === 'metric' ? 'kg' : 'lbs';
  const heightUnit = unitSystem === 'metric' ? 'cm' : 'in';

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Daily Calorie Calculator</CardTitle>
          <CardDescription>
            Enter your details to calculate your daily calorie and macronutrient needs.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="gender"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Gender</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex items-center space-x-4"
                          >
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl><RadioGroupItem value="male" /></FormControl>
                              <FormLabel className="font-normal">Male</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl><RadioGroupItem value="female" /></FormControl>
                              <FormLabel className="font-normal">Female</FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="age"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Age</FormLabel>
                        <FormControl><Input type="number" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="weight"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Weight ({weightUnit})</FormLabel>
                        <FormControl><Input type="number" step="0.1" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="height"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Height ({heightUnit})</FormLabel>
                        <FormControl><Input type="number" step="0.1" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="activityLevel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Activity Level</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger><SelectValue placeholder="Select your activity level" /></SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
                            <SelectItem value="lightlyActive">Lightly Active (light exercise/sports 1-3 days/week)</SelectItem>
                            <SelectItem value="moderatelyActive">Moderately Active (moderate exercise/sports 3-5 days/week)</SelectItem>
                            <SelectItem value="veryActive">Very Active (hard exercise/sports 6-7 days a week)</SelectItem>
                            <SelectItem value="extraActive">Extra Active (very hard exercise/physical job)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="goal"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Goal</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                           <FormControl>
                            <SelectTrigger><SelectValue placeholder="Select your primary goal" /></SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="maintain">Maintain Weight</SelectItem>
                            <SelectItem value="weightLoss">Weight Loss</SelectItem>
                            <SelectItem value="weightGain">Weight Gain</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              <Button type="submit" disabled={isLoading} className="w-full md:w-auto">
                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Calculate
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
      {result && (
        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="flex items-center">
              Your Daily Targets
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div className="p-4 bg-secondary rounded-lg">
                  <p className="text-sm text-muted-foreground">Calories</p>
                  <p className="text-2xl font-bold">{result.dailyCalorieTarget.toLocaleString()}</p>
                  <p className="text-xs text-muted-foreground">kcal</p>
              </div>
              <div className="p-4 bg-secondary rounded-lg">
                  <p className="text-sm text-muted-foreground">Protein</p>
                  <p className="text-2xl font-bold">{result.macroTargets.proteinGrams}</p>
                  <p className="text-xs text-muted-foreground">grams</p>
              </div>
              <div className="p-4 bg-secondary rounded-lg">
                  <p className="text-sm text-muted-foreground">Carbs</p>
                  <p className="text-2xl font-bold">{result.macroTargets.carbGrams}</p>
                  <p className="text-xs text-muted-foreground">grams</p>
              </div>
              <div className="p-4 bg-secondary rounded-lg">
                  <p className="text-sm text-muted-foreground">Fat</p>
                  <p className="text-2xl font-bold">{result.macroTargets.fatGrams}</p>
                  <p className="text-xs text-muted-foreground">grams</p>
              </div>
          </CardContent>
        </Card>
      )}
    </>
  );
}
