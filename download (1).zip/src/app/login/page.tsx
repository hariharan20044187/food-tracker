import { AuthForm } from '@/components/auth-form';
import { Logo } from '@/components/icons';

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center mb-6">
            <Logo className="h-12 w-12 text-primary" />
            <h1 className="text-3xl font-bold tracking-tight font-headline mt-2">GainzTrack</h1>
            <p className="text-muted-foreground mt-1">Your smart fitness journey starts here.</p>
        </div>
        <AuthForm />
      </div>
    </div>
  );
}
