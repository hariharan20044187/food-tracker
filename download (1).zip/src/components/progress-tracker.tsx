"use client";

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import type { CalorieTargets, LoggedMeal } from '@/lib/types';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { PieChart, Pie, Cell } from 'recharts';

interface Props {
  calorieTargets: CalorieTargets | null;
  loggedMeals: LoggedMeal[];
}

const chartConfig = {
  protein: {
    label: "Protein",
    color: "hsl(var(--chart-1))",
  },
  carbs: {
    label: "Carbs",
    color: "hsl(var(--chart-2))",
  },
  fat: {
    label: "Fat",
    color: "hsl(var(--chart-3))",
  },
};

export default function ProgressTracker({ calorieTargets, loggedMeals }: Props) {
  const totals = loggedMeals.reduce(
    (acc, meal) => {
      const multiplier = meal.quantity / meal.food.servingSize;
      acc.calories += meal.food.calories * multiplier;
      acc.protein += meal.food.protein * multiplier;
      acc.carbs += meal.food.carbs * multiplier;
      acc.fat += meal.food.fat * multiplier;
      return acc;
    },
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );

  if (!calorieTargets) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Daily Progress</CardTitle>
          <CardDescription>Your nutritional dashboard.</CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-24">
          <p className="text-muted-foreground">Calculate your daily targets on the 'Target Calculator' tab to see your progress.</p>
        </CardContent>
      </Card>
    );
  }

  const calorieProgress = (totals.calories / calorieTargets.dailyCalorieTarget) * 100;
  const proteinProgress = (totals.protein / calorieTargets.macroTargets.proteinGrams) * 100;
  const carbProgress = (totals.carbs / calorieTargets.macroTargets.carbGrams) * 100;
  const fatProgress = (totals.fat / calorieTargets.macroTargets.fatGrams) * 100;

  const macroData = [
    { name: 'Protein', value: Math.round(totals.protein * 4), color: chartConfig.protein.color },
    { name: 'Carbs', value: Math.round(totals.carbs * 4), color: chartConfig.carbs.color },
    { name: 'Fat', value: Math.round(totals.fat * 9), color: chartConfig.fat.color },
  ].filter(d => d.value > 0);
  
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
      <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
              <CardTitle>Calories</CardTitle>
              <CardDescription>{Math.round(totals.calories)} / {calorieTargets.dailyCalorieTarget} kcal</CardDescription>
          </CardHeader>
          <CardContent>
              <Progress value={calorieProgress} />
          </CardContent>
      </Card>
      <Card>
          <CardHeader className="pb-2">
              <CardTitle>Protein</CardTitle>
              <CardDescription>{Math.round(totals.protein)} / {calorieTargets.macroTargets.proteinGrams} g</CardDescription>
          </CardHeader>
          <CardContent>
              <Progress value={proteinProgress} className="[&>div]:bg-[--chart-1]" />
          </CardContent>
      </Card>
      <Card>
          <CardHeader className="pb-2">
              <CardTitle>Carbs</CardTitle>
              <CardDescription>{Math.round(totals.carbs)} / {calorieTargets.macroTargets.carbGrams} g</CardDescription>
          </CardHeader>
          <CardContent>
              <Progress value={carbProgress} className="[&>div]:bg-[--chart-2]" />
          </CardContent>
      </Card>
      <Card>
          <CardHeader className="pb-2">
              <CardTitle>Fat</CardTitle>
              <CardDescription>{Math.round(totals.fat)} / {calorieTargets.macroTargets.fatGrams} g</CardDescription>
          </CardHeader>
          <CardContent>
              <Progress value={fatProgress} className="[&>div]:bg-[--chart-3]" />
          </CardContent>
      </Card>
        {loggedMeals.length > 0 && (
          <Card className="md:col-span-2 lg:col-span-5">
              <CardHeader>
                  <CardTitle>Calorie Distribution</CardTitle>
                  <CardDescription>Breakdown of calories from protein, carbs, and fat.</CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                  <ChartContainer config={chartConfig} className="mx-auto aspect-square h-[250px]">
                      <PieChart>
                          <ChartTooltip cursor={false} content={<ChartTooltipContent hideLabel />} />
                          <Pie data={macroData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} strokeWidth={5} labelLine={false} label={({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
                            const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
                            const x = cx + radius * Math.cos(-midAngle * (Math.PI / 180));
                            const y = cy + radius * Math.sin(-midAngle * (Math.PI / 180));
                            return (
                                <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central" className="text-xs font-bold">
                                    {`${(percent * 100).toFixed(0)}%`}
                                </text>
                            );
                          }}>
                              {macroData.map((entry) => (
                                  <Cell key={entry.name} fill={entry.color} />
                              ))}
                          </Pie>
                      </PieChart>
                  </ChartContainer>
              </CardContent>
          </Card>
      )}
    </div>
  );
}
