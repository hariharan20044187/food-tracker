"use client";

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { foodData } from '@/lib/data';
import type { Food, LoggedMeal } from '@/lib/types';
import { PlusCircle, Search, Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';

interface Props {
  onMealLog: (meal: LoggedMeal) => void;
  loggedMeals: LoggedMeal[];
  onClearMeals: () => void;
}

const logSchema = z.object({
  quantity: z.coerce.number().min(1, 'Quantity must be at least 1.'),
});

function AddMealDialog({ food, onMealLog }: { food: Food, onMealLog: (meal: LoggedMeal) => void }) {
  const [open, setOpen] = useState(false);
  const form = useForm<{ quantity: number }>({
    resolver: zodResolver(logSchema),
    defaultValues: {
      quantity: food.servingSize,
    },
  });

  function onSubmit(data: { quantity: number }) {
    onMealLog({ id: crypto.randomUUID(), food, quantity: data.quantity });
    setOpen(false);
    form.reset();
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon"><PlusCircle className="h-5 w-5 text-primary" /></Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Log {food.name}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="quantity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantity (g)</FormLabel>
                  <FormControl><Input type="number" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
              <Button type="submit">Log Meal</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}

export default function MealLogger({ onMealLog, loggedMeals, onClearMeals }: Props) {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<Food[]>([]);

  useEffect(() => {
    if (searchTerm.trim() === '') {
      setSearchResults([]);
      return;
    }
    const results = foodData.filter(food =>
      food.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setSearchResults(results.slice(0, 10)); // Limit results for performance
  }, [searchTerm]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
      <Card>
        <CardHeader>
          <CardTitle>Search Food</CardTitle>
          <CardDescription>Find food items to add to your daily log.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search for food..."
              className="pl-8"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="mt-4 max-h-96 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Food</TableHead>
                  <TableHead className="text-right">Calories</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {searchResults.map(food => (
                  <TableRow key={food.name}>
                    <TableCell className="font-medium">{food.name}</TableCell>
                    <TableCell className="text-right">{food.calories} kcal</TableCell>
                    <TableCell className="text-right">
                      <AddMealDialog food={food} onMealLog={onMealLog} />
                    </TableCell>
                  </TableRow>
                ))}
                {searchTerm && searchResults.length === 0 && (
                   <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground">No results found.</TableCell></TableRow>
                )}
                 {!searchTerm && (
                   <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground">Start typing to search for food.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Today's Log</CardTitle>
          <CardDescription>Meals you have logged today.</CardDescription>
        </CardHeader>
        <CardContent className="max-h-[26rem] overflow-y-auto">
          {loggedMeals.length === 0 ? (
            <p className="text-muted-foreground text-center pt-8">No meals logged yet.</p>
          ) : (
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Food</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                {loggedMeals.map(meal => (
                    <TableRow key={meal.id}>
                    <TableCell className="font-medium">{meal.food.name}</TableCell>
                    <TableCell className="text-right">{meal.quantity}g</TableCell>
                    </TableRow>
                ))}
                </TableBody>
            </Table>
          )}
        </CardContent>
        {loggedMeals.length > 0 && (
            <CardFooter>
                <Button variant="destructive" onClick={onClearMeals} className="w-full">
                    <Trash2 className="mr-2 h-4 w-4" /> Clear Log
                </Button>
            </CardFooter>
        )}
      </Card>
    </div>
  );
}
